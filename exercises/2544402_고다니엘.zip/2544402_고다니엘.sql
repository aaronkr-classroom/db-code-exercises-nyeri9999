-- DB Final Project Skeleton
-- Student Name: 고다니엘
-- Student ID: 2544402

-- 0. DROP TABLE
-- 테스트할 때 편의상 테이블 삭제하려고 만들어 두었음. 기존 테이블(자식 테이블)을 먼저 삭제해야 FOREIGN KEY 참조 관계 충돌 오류가 안 생김
DROP TABLE IF EXISTS assign_bus CASCADE;
DROP TABLE IF EXISTS assign_driver CASCADE;
DROP TABLE IF EXISTS reserve CASCADE;
DROP TABLE IF EXISTS tour CASCADE;
DROP TABLE IF EXISTS driver CASCADE;
DROP TABLE IF EXISTS tour_bus CASCADE;
DROP TABLE IF EXISTS staff CASCADE;
DROP TABLE IF EXISTS customer CASCADE;
DROP TABLE IF EXISTS task_code CASCADE;
DROP TABLE IF EXISTS class_code CASCADE;

-- 1. CREATE TABLE

-- class_code
-- 고객의 등급을 숫자 코드로 관리하기 위한 기준 테이블이다. 
-- 1=최우수, 2=우수, 3=일반으로 정의되어 있음.
CREATE TABLE class_code (
                             code INT PRIMARY KEY,
                             class VARCHAR(10),
                             basis VARCHAR(20)
);

-- task_code
-- 직원의 담당업무를 숫자 코드로 관리하기 위한 기준 테이블이다.
CREATE TABLE task_code (
                           code INT PRIMARY KEY,
                           task VARCHAR(30)
);

-- TODO: customer
CREATE TABLE customer (
                          cus_id VARCHAR(15) PRIMARY KEY,
                          name VARCHAR(20) NOT NULL,
                          cell CHAR(13) NOT NULL UNIQUE,
                          addr VARCHAR(100),
                          c_code INT DEFAULT 3,
                          FOREIGN KEY (c_code) REFERENCES class_code(code)
);

-- TODO: staff
CREATE TABLE staff (
                       staff_id INT PRIMARY KEY,
                       name VARCHAR(20) NOT NULL,
                       birthday INT NOT NULL,
                       tel CHAR(12),
                       salary INT,
                       t_code INT NOT NULL,
                       hire_date CHAR(8) NOT NULL,
                       FOREIGN KEY (t_code) REFERENCES task_code(code)
);

-- TODO: tour
CREATE TABLE tour (
                      tour_num CHAR(8) PRIMARY KEY,
                      departure VARCHAR(50) NOT NULL,
                      arrival VARCHAR(50) NOT NULL,
                      program VARCHAR(100),
                      start_dt DATE NOT NULL,
                      end_dt DATE NOT NULL,
                      min_num INT,
                      max_num INT,
                      expense INT NOT NULL,
                      deposit INT,
                      dept_yn CHAR(1) DEFAULT 'N',
                      staff_id INT,
                      FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

-- TODO: reserve
CREATE TABLE reserve (
                         cus_id VARCHAR(15),
                         tour_num CHAR(8),
                         res_date CHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'),
                         dep_yn CHAR(1) DEFAULT 'N',
                         exp_yn CHAR(1) DEFAULT 'N',
                         PRIMARY KEY (cus_id, tour_num),
                         FOREIGN KEY (cus_id) REFERENCES customer(cus_id) ON DELETE CASCADE,
                         FOREIGN KEY (tour_num) REFERENCES tour(tour_num) ON DELETE CASCADE
);
-- =======================================
-- 5. BONUS TABLES(Optional)
-- 안해도 되는데 이왕 하는 김에 해보고 싶어서 했습니다.
-- =======================================

-- driver
-- 여행상품에 배정될 운전기사 정보를 저장한다.
CREATE TABLE driver (
                        driver_id INT PRIMARY KEY,
                        name VARCHAR(20) NOT NULL,
                        birthday CHAR(6) NOT NULL,
                        cell CHAR(13) NOT NULL,
                        pay INT DEFAULT 15000,
                        cont_date CHAR(8),
                        cont_term CHAR(8)
);

-- tour_bus
-- 여행상품에 배정될 관광버스 정보를 저장한다.
CREATE TABLE tour_bus (
                          bus_id INT PRIMARY KEY,
                          seat INT,
                          del_yesr INT
);

-- assign_driver
-- 여행상품과 운전기사의 배정 관계를 저장한다.
CREATE TABLE assign_driver (
                               tour_num CHAR(8),
                               driver_id INT,
                               work_hour INT,
                               PRIMARY KEY (tour_num),
                               FOREIGN KEY (tour_num) REFERENCES tour(tour_num) ON DELETE CASCADE,
                               FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- assign_bus
-- 여행상품과 관광버스의 배정 관계를 저장한다.
CREATE TABLE assign_bus (
                            tour_num CHAR(8),
                            bus_id INT,
                            PRIMARY KEY (tour_num),
                            FOREIGN KEY (tour_num) REFERENCES tour(tour_num) ON DELETE CASCADE,
                            FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);

-- 2. INSERT DATA
-- FOREIGN KEY 참조 순서 때문에 코드 테이블과 부모 테이블 데이터를 먼저 삽입해야 함!
-- TODO: 5개 데이터 삽입해야 됨!

-- 고객등급코드 데이터
INSERT INTO class_code (code, class, basis) VALUES
                                                (1, '최우수', '누적예약 10회 이상'),
                                                (2, '우수', '누적예약 5회 이상'),
                                                (3, '일반', '기본 등급');

-- 직원업무코드 데이터
INSERT INTO task_code (code, task) VALUES
                                       (1, '여행상품관리'),
                                       (2, '예약관리'),
                                       (3, '관광버스배차관리'),
                                       (4, '직원관리'),
                                       (5, '고객관리');

-- 고객 데이터
INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
                                                            ('CUST001', '김민준', '010-1111-1111', '서울시 강남구', 1),
                                                            ('CUST002', '이서연', '010-2222-2222', '서울시 마포구', 2),
                                                            ('CUST003', '박지훈', '010-3333-3333', '부산시 해운대구', 3),
                                                            ('CUST004', '최유진', '010-4444-4444', '대구시 수성구', 3),
                                                            ('CUST005', '정도윤', '010-5555-5555', '인천시 연수구', 2);

-- 직원 데이터
INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
                                                                                 (10001, '한지민', 900101, '02-1111-1111', 3200000, 1, '20200115'),
                                                                                 (10002, '오세훈', 880305, '02-2222-2222', 3000000, 2, '20210201'),
                                                                                 (10003, '문가영', 920710, '02-3333-3333', 3100000, 3, '20200320'),
                                                                                 (10004, '장현우', 850912, '02-4444-4444', 3500000, 4, '20190110'),
                                                                                 (10005, '서예린', 950625, '02-5555-5555', 2900000, 5, '20220505');

-- 여행상품 데이터
INSERT INTO tour (tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
                                                                                                                                     ('TOUR0001', '서울', '부산', 'https://travel.example.com/busan', '2026-07-01', '2026-07-03', 10, 30, 250000, 50000, 'N', 10001),
                                                                                                                                     ('TOUR0002', '서울', '제주', 'https://travel.example.com/jeju', '2026-07-10', '2026-07-13', 12, 25, 480000, 100000, 'N', 10001),
                                                                                                                                     ('TOUR0003', '대전', '경주', 'https://travel.example.com/gyeongju', '2026-08-05', '2026-08-06', 8, 20, 180000, 30000, 'N', 10002),
                                                                                                                                     ('TOUR0004', '부산', '강릉', 'https://travel.example.com/gangneung', '2026-08-15', '2026-08-17', 10, 28, 320000, 70000, 'N', 10003),
                                                                                                                                     ('TOUR0005', '광주', '여수', 'https://travel.example.com/yeosu', '2026-09-01', '2026-09-02', 8, 18, 160000, 30000, 'N', 10002);

-- 예약 데이터
INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
                                                                     ('CUST001', 'TOUR0001', '20260601', 'Y', 'Y'),
                                                                     ('CUST002', 'TOUR0001', '20260602', 'Y', 'N'),
                                                                     ('CUST003', 'TOUR0002', '20260603', 'N', 'N'),
                                                                     ('CUST004', 'TOUR0003', '20260604', 'Y', 'Y'),
                                                                     ('CUST005', 'TOUR0004', '20260605', 'N', 'N');

-- 운전기사 데이터
INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
                                                                                    (20001, '강민수', '800101', '010-6666-1111', 15000, '20260101', '00000012'),
                                                                                    (20002, '노지훈', '820205', '010-6666-2222', 16000, '20260101', '00000012'),
                                                                                    (20003, '류하늘', '790315', '010-6666-3333', 15500, '20260201', '00000006'),
                                                                                    (20004, '배성민', '850920', '010-6666-4444', 17000, '20260301', '00000012'),
                                                                                    (20005, '윤도현', '881130', '010-6666-5555', 15000, '20260401', '00000006');

-- 관광버스 데이터
INSERT INTO tour_bus (bus_id, seat, del_yesr) VALUES
                                                  (1, 25, 2020),
                                                  (2, 30, 2021),
                                                  (3, 35, 2019),
                                                  (4, 28, 2022),
                                                  (5, 40, 2023);

-- 기사배정 데이터
INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
                                                               ('TOUR0001', 20001, 16),
                                                               ('TOUR0002', 20002, 24),
                                                               ('TOUR0003', 20003, 8),
                                                               ('TOUR0004', 20004, 18),
                                                               ('TOUR0005', 20005, 10);

-- 차량배정 데이터
INSERT INTO assign_bus (tour_num, bus_id) VALUES
                                              ('TOUR0001', 1),
                                              ('TOUR0002', 2),
                                              ('TOUR0003', 3),
                                              ('TOUR0004', 4),
                                              ('TOUR0005', 5);

-- 3. INDEX
-- TODO: CREATE INDEX
-- tour_arrival_idx는 도착지 검색 성능 향상을 위한 인덱스다.
CREATE INDEX tour_arrival_idx
    ON tour (arrival);

-- driver_name_idx는 운전기사 이름 검색과 정렬 성능 향상을 위한 인덱스다.
CREATE INDEX driver_name_idx
    ON driver (name);

-- 4. TEST QUERIES

-- Customer Grade Search
-- 입력한 고객 id의 고객명과 등급명을 조회한다.
SELECT c.name, cc.class
FROM customer c
         JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'CUST001';

-- Employee Task Search
-- 입력한 사번의 직원명과 담당업무명을 조회한다.
SELECT s.name, tc.task
FROM staff s
         JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10001;

-- Tour Reservation Search
-- 입력한 여행번호를 예약한 고객명, 예약일자, 예약금결제여부를 조회한다.
SELECT c.name, r.res_date, r.dep_yn
FROM reserve r
         JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'TOUR0001';

-- Assigned Driver Search
-- 입력한 여행번호의 출발지, 배정 운전기사명, 휴대폰번호를 조회한다.
SELECT t.departure, d.name, d.cell
FROM tour t
         JOIN assign_driver ad ON t.tour_num = ad.tour_num
         JOIN driver d ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'TOUR0001';

-- INSERT example
-- c_code를 생략하면 DEFAULT 3이 적용되어 일반 등급 고객으로 등록되기 때문에 주의해야 함!!
INSERT INTO customer (cus_id, name, cell)
VALUES ('CUST006', '신나래', '010-7777-7777');

SELECT c.cus_id, c.name, c.cell, cc.class
FROM customer c
         JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'CUST006';

-- UPDATE example
-- 입력한 사번의 직원 급여를 예시로 20만원 증가시킨다.
SELECT staff_id, name, salary
FROM staff
WHERE staff_id = 10001;

UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10001;

SELECT staff_id, name, salary
FROM staff
WHERE staff_id = 10001;

-- DELETE example
-- 입력한 고객 id와 여행번호에 해당하는 예약 정보를 삭제한다.
SELECT *
FROM reserve
WHERE cus_id = 'CUST002'
  AND tour_num = 'TOUR0001';

DELETE FROM reserve
WHERE cus_id = 'CUST002'
  AND tour_num = 'TOUR0001';

SELECT *
FROM reserve
WHERE cus_id = 'CUST002'
  AND tour_num = 'TOUR0001';
